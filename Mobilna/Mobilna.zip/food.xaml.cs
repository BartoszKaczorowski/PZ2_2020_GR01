﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MniamPL
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class food : ContentPage
	{
        string id;
        string idLokalu;
        Dictionary<string, string> cart = new Dictionary<string, string>();
        public food (string lokal, string id) {
			InitializeComponent ();
            this.id = id;
            //idLokalu = lokal.Split(',')[0];
            idLokalu = lokal;
            lab.Text = "Loading...";
            wyswietlFood();
        }

        async void wyswietlFood() {
            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("idLokalu", idLokalu));
            var content = new FormUrlEncodedContent(postData);
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://doapi.cba.pl");
            var response = await client.PostAsync("http://doapi.cba.pl/food.php", content);
            string result = response.Content.ReadAsStringAsync().Result;
            string[] res = result.Split(';');
            lab.Text = "";
            for (int i = 0; i < res.Count() - 1; i++) {
                string[] product = res[i].Split('+');
                Frame frm = new Frame {
                    CornerRadius = 10,
                    BorderColor = Xamarin.Forms.Color.Black
                };
                StackLayout stc = new StackLayout { };
                Label name = new Label {
                    Text = product[1],
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    HorizontalOptions = LayoutOptions.Center
                };
                stc.Children.Add(name);
                Label prize = new Label {
                    Text = product[3],
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    HorizontalOptions = LayoutOptions.Center
                };
                stc.Children.Add(prize);
                Label desc = new Label {
                    Text = product[2],
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    HorizontalOptions = LayoutOptions.Center
                };
                stc.Children.Add(desc);
                Entry quan = new Entry {
                    Text = "1",
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    HorizontalOptions = LayoutOptions.Center
                };
                stc.Children.Add(quan);
                ButtonWithTag btn = new ButtonWithTag {
                    Text = "DODAJ",
                    Tag = product[0],
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    HorizontalOptions = LayoutOptions.Center
                };
                btn.Clicked += Btn_Clicked;
                stc.Children.Add(btn);
                frm.Content = stc;
                foodStack.Children.Add(frm);
                
            }
        }

        private void Btn_Clicked(object sender, EventArgs e) {
            StackLayout parent = ((sender as Button).Parent as StackLayout);
            string id = (sender as ButtonWithTag).Tag.ToString();
            string quan = (parent.Children[3] as Entry).Text;
            string name = (parent.Children[0] as Label).Text;
            try { cart.Add(name + '*' + id, quan); } catch (Exception err) { }
        }

        public void wyswietlFoodClick(object sender, EventArgs e) {
            if (lab.Text == "") {
                lab.Text = "Loading...";
                foodStack.Children.Clear();
                wyswietlFood();
            }
        }

    }
}