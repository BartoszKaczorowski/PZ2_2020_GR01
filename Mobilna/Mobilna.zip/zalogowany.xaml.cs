﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MniamPL
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class zalogowany : ContentPage
	{
        string login;
        string id;

        public zalogowany(string login, string id) {
            InitializeComponent();
            this.login = login;
            this.id = id;
            helloLabel.Text = "Witaj, " + login;
            lbl.Text = "Loading...";
            wyswietlLokaleAsync();
        }

        public async void wyswietlLokaleAsync() {
            HttpClient client = new HttpClient();
            
            client.BaseAddress = new Uri("http://doapi.cba.pl");

            var response = await client.GetAsync("http://doapi.cba.pl/lokale.php");
            string result = response.Content.ReadAsStringAsync().Result;
            lbl.Text = "";
            string[] res = result.Split(';');
            for (int i=0; i<res.Count()-1; i++) {
                ButtonWithTag button = new ButtonWithTag {
                    Text = res[i].Split(',')[1],
                    Tag = res[i].Split(',')[0],
                    VerticalOptions = LayoutOptions.CenterAndExpand,
                    HorizontalOptions = LayoutOptions.Center
                };
                button.Clicked += OnButtonClick;
                glownyStack.Children.Add(button);
            }
        }

        public void OnButtonClick(object sender, EventArgs e) {
            Navigation.PushModalAsync(new food((sender as ButtonWithTag).Tag.ToString(), id));
        }
        public void wyswietlLokaleAsyncClick(object sender, EventArgs e) {
            if (lbl.Text == "") {
                lbl.Text = "Loading...";
                glownyStack.Children.Clear();
                wyswietlLokaleAsync();
            }
        }
    }
}