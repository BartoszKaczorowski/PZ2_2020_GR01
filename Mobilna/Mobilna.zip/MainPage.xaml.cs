﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MniamPL {
    public partial class MainPage : ContentPage {
        bool flag = false;
        string name;
        string id;
        public MainPage() {
            InitializeComponent();
        }

        void wybiel(object sender, EventArgs e) {
            loginEntry.BackgroundColor = Color.White;
            passwordEntry.BackgroundColor = Color.White;
        }

        async void loginButtClick(object sender, EventArgs e) {
            try {
                loginButt.IsEnabled = false;
                var postData = new List<KeyValuePair<string, string>>();
                postData.Add(new KeyValuePair<string, string>("username", loginEntry.Text));
                postData.Add(new KeyValuePair<string, string>("password", passwordEntry.Text));

                var content = new FormUrlEncodedContent(postData);

                HttpClient client = new HttpClient();

                client.BaseAddress = new Uri("http://doapi.cba.pl");

                var response = await client.PostAsync("http://doapi.cba.pl/login.php", content);
                string result = response.Content.ReadAsStringAsync().Result;
                if (result.StartsWith("Success")) {
                    id = result.Split(',')[1];
                    flag = true;
                }
            } catch (Exception ex) {
                loginButt.IsEnabled = true;
                return;
            }
            if (flag) {
                name = loginEntry.Text;
                await Navigation.PushModalAsync(new zalogowany(name, id));
                flag = false;
                loginButt.IsEnabled = true;
            } else {
                loginEntry.BackgroundColor = Color.IndianRed;
                passwordEntry.BackgroundColor = Color.IndianRed;
                await DisplayAlert("Błąd!", "Złe dane logowania!", "Ok");
                loginButt.IsEnabled = true;
            }
        }
    }
}
