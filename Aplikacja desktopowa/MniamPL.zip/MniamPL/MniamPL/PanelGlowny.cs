﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MniamPL {
    public partial class PanelGlowny : Form {
        string name;
        Form1 f;
        int id;
        MySqlConnection connection = new MySqlConnection("Server=heltica.cba.pl;Port=3306;Database=heltica;Uid=helticadb;Pwd=Helticadb1;");
        MySqlCommand command;
        public PanelGlowny(Form1 f, string name, int id) {
            InitializeComponent();
            this.name = name;
            this.f = f;
            this.id = id;
            label1.Text = name;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            updateDataGrid();
        }

        private void PanelGlowny_FormClosed(object sender, FormClosedEventArgs e) {
            f.Show();
        }

        public void openConnection() {
            if (connection.State == ConnectionState.Closed) {
                connection.Open();
            }
        }

        public void closeConnection() {
            if (connection.State == ConnectionState.Open) {
                connection.Close();
            }
        }

        private void updateDataGrid() {
            string com;
            //string com = "SELECT ZAM.id_zamowienia, ZAM.ulica, ZAM.nr_budynku, ZAM.kod_pocztowy, ZAM.miejscowosc, ZAM.telefon, D.nazwa, ROUND(SZ.ilosc*D.cena,2) cena FROM m_zamowienia ZAM, m_szczegolyzamowienia SZ, m_dania D WHERE D.id_dania=SZ.id_dania AND ZAM.id_zamowienia=SZ.id_zamowienia AND ZAM.id_lokalu="+id;
            if (comboBox1.SelectedItem.ToString() == "Wszystkie") {
                com = "SELECT heltica.m_zamowienia.id_zamowienia AS 'nr',heltica.m_zamowienia.status AS 'status', heltica.m_dania.nazwa AS 'pozycja', heltica.m_szczegolyzamowienia.ilosc AS 'ilosc', heltica.m_dania.cena AS 'cena j.', (ROUND(heltica.m_szczegolyzamowienia.ilosc * heltica.m_dania.cena, 2)) AS 'cena' FROM heltica.m_zamowienia, heltica.m_szczegolyzamowienia, heltica.m_dania WHERE heltica.m_zamowienia.id_zamowienia = heltica.m_szczegolyzamowienia.id_zamowienia AND heltica.m_szczegolyzamowienia.id_dania = heltica.m_dania.id_dania AND heltica.m_zamowienia.id_lokalu =" + id;
            } else {
                com = "SELECT heltica.m_zamowienia.id_zamowienia AS 'nr',heltica.m_zamowienia.status AS 'status', heltica.m_dania.nazwa AS 'pozycja', heltica.m_szczegolyzamowienia.ilosc AS 'ilosc', heltica.m_dania.cena AS 'cena j.', (ROUND(heltica.m_szczegolyzamowienia.ilosc * heltica.m_dania.cena, 2)) AS 'cena' FROM heltica.m_zamowienia, heltica.m_szczegolyzamowienia, heltica.m_dania WHERE heltica.m_zamowienia.id_zamowienia = heltica.m_szczegolyzamowienia.id_zamowienia AND heltica.m_szczegolyzamowienia.id_dania = heltica.m_dania.id_dania AND heltica.m_zamowienia.id_lokalu =" + id + " AND heltica.m_zamowienia.status = '" + comboBox1.SelectedItem.ToString() + "'";
            }
            command = new MySqlCommand(com, connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            openConnection();
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
            closeConnection();
            dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
        }
        string zaznaczony = "";
        float cena = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e) {
            cena = 0;
            zaznaczony = dataGridView1.SelectedRows[0].Cells["nr"].Value.ToString();
            if(zaznaczony == "") {
                label3.Text = "";
                addressLabel.Text = "";
                addressLabel2.Text = "";
                phoneLabel.Text = "";
                return;
            }
            for(int i = 0; i < dataGridView1.Rows.Count-1; i++) {
                if(dataGridView1.Rows[i].Cells["nr"].Value.ToString() == zaznaczony) {
                    dataGridView1.Rows[i].Selected = true;
                    cena += float.Parse(dataGridView1.Rows[i].Cells["cena"].Value.ToString());
                }
            }
            label3.Text = "Cena: " + cena.ToString() + "zł";
            string com = "SELECT m_zamowienia.id_zamowienia AS 'nr zamowienia', CONCAT(m_zamowienia.ulica, ' ', m_zamowienia.nr_budynku) AS 'ulica', CONCAT(m_zamowienia.kod_pocztowy, ' ', m_zamowienia.miejscowosc) AS 'miejscowosc', m_zamowienia.telefon AS 'telefon' FROM m_zamowienia WHERE m_zamowienia.id_zamowienia = " + zaznaczony;
            command = new MySqlCommand(com, connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            openConnection();
            DataTable table = new DataTable();
            adapter.Fill(table);
            addressLabel.Text = "Ulica: " + table.Rows[0][1];
            addressLabel2.Text = "Miejscowość: " + table.Rows[0][2];
            phoneLabel.Text = "Telefon: " + table.Rows[0][3];
            closeConnection();
        }

        private void button1_Click(object sender, EventArgs e) {
            updateStatus((sender as Button).Text);
        }
        private void updateStatus(string status) {
            if (zaznaczony != "") {
                string com = "UPDATE m_zamowienia SET status='" + status + "' WHERE id_zamowienia = " + zaznaczony;
                command = new MySqlCommand(com, connection);
                openConnection();
                command.ExecuteNonQuery();
                closeConnection();
            }
            updateDataGrid();
        }

        private void button2_Click(object sender, EventArgs e) {
            updateStatus((sender as Button).Text);
        }

        private void button3_Click(object sender, EventArgs e) {
            updateStatus((sender as Button).Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) {
            zaznaczony = "";
            updateDataGrid();
        }
    }
}
