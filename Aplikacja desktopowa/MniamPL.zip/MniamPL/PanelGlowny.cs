﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MniamPL {
    public partial class PanelGlowny : Form {
        string name;
        Form1 f;
        int id;
        MySqlConnection connection = new MySqlConnection("Server=heltica.cba.pl;Port=3306;Database=heltica;Uid=helticadb;Pwd=Helticadb1;");
        MySqlCommand command;
        public PanelGlowny(Form1 f, string name, int id) {
            InitializeComponent();
            this.name = name;
            this.f = f;
            this.id = id;
            label1.Text = name;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            updateDataGrid();
        }

        private void PanelGlowny_FormClosed(object sender, FormClosedEventArgs e) {
            f.Show();
        }

        public void openConnection() {
            if (connection.State == ConnectionState.Closed) {
                connection.Open();
            }
        }

        public void closeConnection() {
            if (connection.State == ConnectionState.Open) {
                connection.Close();
            }
        }

        private void updateDataGrid() {
            string com = "SELECT ZAM.id_zamowienia, ZAM.ulica, ZAM.nr_budynku, ZAM.kod_pocztowy, ZAM.miejscowosc, ZAM.telefon, D.nazwa, D.opis, SZ.ilosc*D.cena FROM m_zamowienia ZAM, m_szczegolyzamowienia SZ, m_dania D WHERE D.id_dania=SZ.id_dania AND ZAM.id_zamowienia=SZ.id_zamowienia AND ZAM.id_lokalu="+id;
            command = new MySqlCommand(com, connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            openConnection();
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
            closeConnection();
            dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
        }
    }
}
